package com.mindbowser.springsecurityassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityAssignmentApplication.class, args);
	}

}
