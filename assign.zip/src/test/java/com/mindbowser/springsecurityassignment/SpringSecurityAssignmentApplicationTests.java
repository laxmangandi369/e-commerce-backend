package com.mindbowser.springsecurityassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
