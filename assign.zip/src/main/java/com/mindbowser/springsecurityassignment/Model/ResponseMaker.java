package com.mindbowser.springsecurityassignment.Model;

public class ResponseMaker {

}
